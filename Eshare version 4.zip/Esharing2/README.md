This project is for UI, angularjs stuff goes here.
